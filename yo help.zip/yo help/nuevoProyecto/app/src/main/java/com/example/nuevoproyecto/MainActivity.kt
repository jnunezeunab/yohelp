package com.example.nuevoproyecto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btningresar: Button = findViewById(R.id.btningresar)
        btningresar.setOnClickListener {

            val intent: Intent = Intent(this, Menu:: class.java)
            startActivity(intent)

        }

        val btnregistro: Button = findViewById(R.id.btnregistro)
        btnregistro.setOnClickListener {

            val intent: Intent = Intent(this, RegistroUser:: class.java)
            startActivity(intent)

        }
    }
}